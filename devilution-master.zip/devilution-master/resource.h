//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Diablo.rc
//
#define IDI_ICON1                       101
#define IDD_DIALOG1                     104
#define IDD_DIALOG2                     105
#define IDD_DIALOG3                     106
#define IDD_DIALOG4                     107
#define IDD_DIALOG5                     108
#define IDD_DIALOG6                     109
#define IDD_DIALOG7                     110
#define IDD_DIALOG8                     111
#define IDD_DIALOG9                     112
#define IDD_DIALOG10                    113
#define IDD_DIALOG11                    114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
