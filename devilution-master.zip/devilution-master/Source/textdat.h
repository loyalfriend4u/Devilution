//HEADER_GOES_HERE
#ifndef __TEXTDAT_H__
#define __TEXTDAT_H__

extern TextDataStruct alltext[259];
extern int gdwAllTextEntries;

#endif /* __TEXTDAT_H__ */
