//HEADER_GOES_HERE
#ifndef __RESTRICT_H__
#define __RESTRICT_H__

bool __cdecl SystemSupported();
bool __cdecl RestrictedTest();
bool __cdecl ReadOnlyTest();

#endif /* __RESTRICT_H__ */
